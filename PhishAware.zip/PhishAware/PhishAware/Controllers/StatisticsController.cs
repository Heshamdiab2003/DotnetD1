﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Linq;
using System.Threading.Tasks;

[Route("api/statistics")]
[ApiController]
public class StatisticsController : ControllerBase
{
    private readonly PhishAwareDbContext _context;

    public StatisticsController(PhishAwareDbContext context)
    {
        _context = context;
    }

    // GET: api/statistics
    [HttpGet]
    public async Task<ActionResult<Statistic>> GetStatistics()
    {
        var stats = await _context.Statistics.FirstOrDefaultAsync();
        if (stats == null)
        {
            return NotFound("Statistics not found.");
        }
        return stats;
    }

    // PUT: api/statistics/update
    [HttpPut("update")]
    public async Task<IActionResult> UpdateStatistics()
    {
        var stats = await _context.Statistics.FirstOrDefaultAsync();
        if (stats == null)
        {
            return NotFound("Statistics record not found.");
        }

        stats.Total_URI = await _context.URLs.CountAsync();
        stats.Total_SMS = await _context.SMSs.CountAsync();
        stats.UnsafeURLs = await _context.URLs.CountAsync(u => u.ScanResult == "Unsafe");
        stats.Safe_Urls = await _context.URLs.CountAsync(u => u.ScanResult == "Safe");
        stats.Unsafe_SMS = await _context.SMSs.CountAsync(s => s.ScanResult == "Unsafe");
        stats.Safe_SMS = await _context.SMSs.CountAsync(s => s.ScanResult == "Safe");

        await _context.SaveChangesAsync();
        return NoContent();
    }
}
