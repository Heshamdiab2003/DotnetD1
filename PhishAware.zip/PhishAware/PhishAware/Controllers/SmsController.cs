﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

[Route("api/sms")]
[ApiController]
public class SmsController : ControllerBase
{
    private readonly PhishAwareDbContext _context;

    public SmsController(PhishAwareDbContext context)
    {
        _context = context;
    }

    // GET: api/sms
    [HttpGet]
    public async Task<ActionResult<IEnumerable<SMS>>> GetSMSs()
    {
        return await _context.SMSs.ToListAsync();
    }

    // GET: api/sms/{id}
    [HttpGet("{id}")]
    public async Task<ActionResult<SMS>> GetSMS(int id)
    {
        var sms = await _context.SMSs.FindAsync(id);
        if (sms == null)
        {
            return NotFound("SMS not found.");
        }
        return sms;
    }

    // POST: api/sms
    [HttpPost]
    public async Task<ActionResult<SMS>> CreateSMS(SMS sms)
    {
        _context.SMSs.Add(sms);
        await _context.SaveChangesAsync();

        return CreatedAtAction(nameof(GetSMS), new { id = sms.SMS_ID }, sms);
    }

    // DELETE: api/sms/{id}
    [HttpDelete("{id}")]
    public async Task<IActionResult> DeleteSMS(int id)
    {
        var sms = await _context.SMSs.FindAsync(id);
        if (sms == null)
        {
            return NotFound("SMS not found.");
        }

        _context.SMSs.Remove(sms);
        await _context.SaveChangesAsync();
        return NoContent();
    }
}
