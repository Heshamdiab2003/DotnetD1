﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

[Route("api/urls")]
[ApiController]
public class UrlsController : ControllerBase
{
    private readonly PhishAwareDbContext _context;

    public UrlsController(PhishAwareDbContext context)
    {
        _context = context;
    }

    [HttpGet]
    public async Task<ActionResult<IEnumerable<Url>>> GetUrls()
    {
        return await _context.URLs.ToListAsync();
    }

    [HttpPost]
    public async Task<ActionResult<Url>> CreateUrl(Url url)
    {
        _context.URLs.Add(url);
        await _context.SaveChangesAsync();
        return CreatedAtAction(nameof(GetUrls), new { id = url.Url_ID }, url);
    }
}
