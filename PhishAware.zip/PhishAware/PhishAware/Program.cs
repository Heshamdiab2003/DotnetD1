
using Supabase;

namespace PhishAware
{
    public class Program
    {
        public static void Main(string[] args)
        {
            var builder = WebApplication.CreateBuilder(args);
            // config for supabase client
            builder.Services.AddScoped<Supabase.Client>(_ =>
            new Supabase.Client(
                builder.Configuration["SupabaseUrl"],
                 builder.Configuration["SupabaseKey"],
               new SupabaseOptions
               {
                   AutoRefreshToken = true,
                   AutoConnectRealtime = true,
               }));
            // Add services to the container.

            builder.Services.AddControllers();
            // Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
            builder.Services.AddEndpointsApiExplorer();
            builder.Services.AddSwaggerGen();

            var app = builder.Build();

            // Configure the HTTP request pipeline.
            if (app.Environment.IsDevelopment())
            {
                app.UseSwagger();
                app.UseSwaggerUI();
            }

            app.UseAuthorization();


            app.MapControllers();

            app.Run();
        }
    }
}
