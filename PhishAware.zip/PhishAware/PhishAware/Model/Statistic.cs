﻿using System.ComponentModel.DataAnnotations;

public class Statistic
{
    [Key]
    public int stat_ID { get; set; }
    public int Total_URI { get; set; } = 0;
    public int Total_SMS { get; set; } = 0;
    public int UnsafeURLs { get; set; } = 0;
    public int Safe_Urls { get; set; } = 0;
    public int Unsafe_SMS { get; set; } = 0;
    public int Safe_SMS { get; set; } = 0;
}
