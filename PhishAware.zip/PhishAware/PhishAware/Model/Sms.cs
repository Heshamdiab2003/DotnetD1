﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

public class SMS
{
    [Key]
    public int SMS_ID { get; set; }
    [Required]
    public string SMS_text { get; set; }
    [Required]
    public string ScanResult { get; set; }
    public DateTime CheckDate { get; set; } = DateTime.UtcNow;

    [ForeignKey("User")]
    public int User_ID { get; set; }
    public User User { get; set; }
}
