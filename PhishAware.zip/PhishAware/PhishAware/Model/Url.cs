﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

public class Url
{
    [Key]
    public int Url_ID { get; set; }
    [Required]
    public string URL_string { get; set; }
    [Required]
    public string ScanResult { get; set; }
    public DateTime CheckDate { get; set; } = DateTime.UtcNow;

    [ForeignKey("User")]
    public int User_ID { get; set; }
    public User User { get; set; }
}
