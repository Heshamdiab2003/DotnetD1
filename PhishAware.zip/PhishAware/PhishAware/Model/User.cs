﻿using System.ComponentModel.DataAnnotations;

public class User
{
    [Key]
    public int ID_user { get; set; }
    [Required]
    public string User_Name { get; set; }
    [Required, EmailAddress]
    public string Email { get; set; }
    [Required]
    public string Password { get; set; }
    public string? Profile_Picture { get; set; }
}
