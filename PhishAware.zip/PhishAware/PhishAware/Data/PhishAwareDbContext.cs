using Microsoft.EntityFrameworkCore;

using System.Collections.Generic;

public class PhishAwareDbContext : DbContext
{
    public PhishAwareDbContext(DbContextOptions<PhishAwareDbContext> options) : base(options) { }

    public DbSet<User> Users { get; set; }
    public DbSet<Url> URLs { get; set; }
    public DbSet<SMS> SMSs { get; set; }
    public DbSet<Statistic> Statistics { get; set; }
}
