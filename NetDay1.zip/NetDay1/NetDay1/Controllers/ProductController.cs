﻿using Microsoft.AspNetCore.Mvc;
using YourProject.BusinessLogic;
using YourProject.Data;
using YourProject.Models;

namespace YourProject.Controllers
{
    public class ProductController : Controller
    {
        private readonly ProductBL _productBL;

        public ProductController(ApplicationDbContext context)
        {
            _productBL = new ProductBL(context);
        }

        public IActionResult Index()
        {
            var products = _productBL.GetAll();
            return View(products);
        }

        public IActionResult Details(int id)
        {
            var product = _productBL.GetById(id);
            if (product == null)
            {
                return NotFound();
            }
            return View(product);
        }

        public IActionResult Create()
        {
            return View();
        }

        [HttpPost]
        public IActionResult Create(Product product)
        {
            if (ModelState.IsValid)
            {
                _productBL.AddProduct(product);
                return RedirectToAction("Index");
            }
            return View(product);
        }
    }
}
