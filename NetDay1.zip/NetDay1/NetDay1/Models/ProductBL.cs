﻿using YourProject.Data;
using YourProject.Models;

namespace YourProject.BusinessLogic
{
    public class ProductBL
    {
        private readonly ApplicationDbContext _context;

        public ProductBL(ApplicationDbContext context)
        {
            _context = context;
        }

        public List<Product> GetAll()
        {
            return _context.Products.ToList();
        }

        public Product GetById(int id)
        {
            return _context.Products.FirstOrDefault(p => p.Id == id);
        }

        public void AddProduct(Product product)
        {
            _context.Products.Add(product);
            _context.SaveChanges();
        }
    }
}
